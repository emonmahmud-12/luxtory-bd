-- Luxtory Bd FINAL backend setup
-- Run once in Supabase SQL Editor. Uses your existing ecommerce tables.
create extension if not exists pgcrypto;

create table if not exists public.store_admins(
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.store_admins enable row level security;
drop policy if exists "store admin self read" on public.store_admins;
create policy "store admin self read" on public.store_admins for select to authenticated using (user_id=auth.uid());

-- Guest checkout: one safe RPC. Client cannot directly read/write orders/customers.
create or replace function public.create_guest_order(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  cust jsonb := coalesce(payload->'customer','{}'::jsonb);
  items jsonb := coalesce(payload->'items','[]'::jsonb);
  c_id uuid; o_id uuid; o_no text; item jsonb; p record; v record;
  qty int; unit numeric; sub numeric := 0; delivery numeric := 0;
  city text := lower(trim(coalesce(cust->>'city','')));
begin
  if jsonb_array_length(items)=0 then raise exception 'Cart is empty'; end if;
  if length(trim(coalesce(cust->>'name','')))<2 then raise exception 'Name is required'; end if;
  if length(regexp_replace(coalesce(cust->>'phone',''),'[^0-9]','','g'))<8 then raise exception 'Valid phone is required'; end if;
  if length(trim(coalesce(cust->>'address','')))<5 then raise exception 'Address is required'; end if;

  insert into customers(name,phone,email,address,area,city,district)
  values(trim(cust->>'name'),trim(cust->>'phone'),nullif(trim(cust->>'email'),''),
         trim(cust->>'address'),nullif(trim(cust->>'area'),''),
         nullif(trim(cust->>'city'),'Dhaka'),nullif(trim(cust->>'district'),''))
  returning id into c_id;

  for item in select jsonb_array_elements(items)
  loop
    if nullif(item->>'product_id','') is null then raise exception 'Invalid product'; end if;
    qty := greatest(1, least(coalesce((item->>'quantity')::int,1),20));
    select * into p from products where id=(item->>'product_id')::uuid and status='active';
    if not found then raise exception 'Product unavailable'; end if;

    if nullif(item->>'variant_id','') is not null then
      select * into v from product_variants where id=(item->>'variant_id')::uuid and product_id=p.id and status='active' for update;
      if not found or v.stock < qty then raise exception 'Variant is out of stock'; end if;
      unit := coalesce(v.discount_price,v.price,p.discount_price,p.price,0);
    else
      if exists(select 1 from product_variants where product_id=p.id and status='active') then raise exception 'Please select a variant'; end if;
      unit := coalesce(p.discount_price,p.price,0);
    end if;
    sub := sub + unit*qty;
  end loop;

  if city in ('dhaka','ঢাকা') then
    select coalesce(inside_dhaka_charge,0) into delivery from delivery_settings where active=true order by created_at desc limit 1;
  else
    select coalesce(outside_dhaka_charge,0) into delivery from delivery_settings where active=true order by created_at desc limit 1;
  end if;
  delivery := coalesce(delivery,0);

  o_no := 'LB-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
  insert into orders(order_number,customer_id,customer_name,customer_phone,customer_email,
    shipping_address,shipping_area,shipping_city,shipping_district,subtotal,delivery_charge,
    discount_amount,total_amount,payment_method,payment_status,order_status)
  values(o_no,c_id,trim(cust->>'name'),trim(cust->>'phone'),nullif(trim(cust->>'email'),''),
    trim(cust->>'address'),nullif(trim(cust->>'area'),''),nullif(trim(cust->>'city'),''),
    nullif(trim(cust->>'district'),''),sub,delivery,0,sub+delivery,'cod','unpaid','pending')
  returning id into o_id;

  for item in select jsonb_array_elements(items)
  loop
    qty := greatest(1, least(coalesce((item->>'quantity')::int,1),20));
    select * into p from products where id=(item->>'product_id')::uuid and status='active';
    if nullif(item->>'variant_id','') is not null then
      select * into v from product_variants where id=(item->>'variant_id')::uuid and product_id=p.id and status='active' for update;
      unit := coalesce(v.discount_price,v.price,p.discount_price,p.price,0);
      update product_variants set stock=stock-qty,updated_at=now() where id=v.id;
      insert into order_items(order_id,product_id,variant_id,product_name,sku,size,color,quantity,unit_price,discount_price,total_price)
      values(o_id,p.id,v.id,p.name,coalesce(v.sku,p.sku),v.size,v.color,qty,coalesce(v.price,p.price),v.discount_price,unit*qty);
    else
      unit := coalesce(p.discount_price,p.price,0);
      insert into order_items(order_id,product_id,product_name,sku,quantity,unit_price,discount_price,total_price)
      values(o_id,p.id,p.name,p.sku,qty,p.price,p.discount_price,unit*qty);
    end if;
  end loop;

  insert into order_status_history(order_id,new_status,note) values(o_id,'pending','Guest order created');
  return jsonb_build_object('order_id',o_id,'order_number',o_no);
end;
$$;

revoke all on function public.create_guest_order(jsonb) from public;
grant execute on function public.create_guest_order(jsonb) to anon, authenticated;

-- Public catalog
alter table products enable row level security;
alter table product_images enable row level security;
alter table product_variants enable row level security;
drop policy if exists "public active products" on products;
create policy "public active products" on products for select to anon,authenticated using(status='active');
drop policy if exists "public product images" on product_images;
create policy "public product images" on product_images for select to anon,authenticated using(exists(select 1 from products p where p.id=product_images.product_id and p.status='active'));
drop policy if exists "public active variants" on product_variants;
create policy "public active variants" on product_variants for select to anon,authenticated using(status='active' and exists(select 1 from products p where p.id=product_variants.product_id and p.status='active'));

-- Admin policies for existing store tables
create or replace function public.is_store_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from store_admins where user_id=auth.uid());
$$;
revoke all on function public.is_store_admin() from public;
grant execute on function public.is_store_admin() to authenticated;

-- Admin CRUD policies
do $$
declare t text;
begin
  foreach t in array array['products','product_images','product_variants','orders','order_items','customers','delivery_settings','coupons','store_banners','store_settings','order_status_history']
  loop
    execute format('drop policy if exists "admin all %s" on public.%I',t,t);
    execute format('create policy "admin all %s" on public.%I for all to authenticated using(public.is_store_admin()) with check(public.is_store_admin())',t,t);
  end loop;
end $$;

-- Keep public settings/banner access
drop policy if exists "public active banners" on store_banners;
create policy "public active banners" on store_banners for select to anon,authenticated using(active=true);
drop policy if exists "public store settings" on store_settings;
create policy "public store settings" on store_settings for select to anon,authenticated using(true);

-- Storage bucket for product images
insert into storage.buckets(id,name,public) values('product-images','product-images',true)
on conflict(id) do update set public=true;
drop policy if exists "admin upload product images" on storage.objects;
create policy "admin upload product images" on storage.objects for insert to authenticated
with check(bucket_id='product-images' and public.is_store_admin());
drop policy if exists "public read product images" on storage.objects;
create policy "public read product images" on storage.objects for select to anon,authenticated using(bucket_id='product-images');
